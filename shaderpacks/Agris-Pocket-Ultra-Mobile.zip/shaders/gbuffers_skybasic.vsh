#version 120
varying vec4 vColor;
varying vec3 vViewPos;
void main() {
    vColor = gl_Color;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    vViewPos = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}
