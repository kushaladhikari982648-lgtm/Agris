#version 120
/* RENDERTARGETS: 0 */
varying vec4 vColor;
void main() { gl_FragData[0] = vec4(vColor.rgb, 0.5); }
