#version 120
#include "/lib/mobile_settings.glsl"
attribute vec4 mc_Entity;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

varying vec2 vUv;
varying vec2 vLightUv;
varying vec4 vColor;
varying vec4 vShadowCoord;
varying float vNdotL;
varying float vSkyHemi;
varying float vViewDist;
varying float vEmissive;

void main() {
    vUv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLightUv = clamp((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy, 0.03125, 0.96875);
    vColor = gl_Color;
    vEmissive = abs(mc_Entity.x - 10040.0) < 0.5 ? 1.0 : 0.0;

    vec4 localPos = gl_Vertex;
    #ifdef WAVING_FOLIAGE
    if (abs(mc_Entity.x - 10020.0) < 0.5) {
        vec3 wp = localPos.xyz + cameraPosition;
        float ph = frameTimeCounter * 2.6 + wp.x * 0.7 + wp.z * 0.7;
        localPos.x += sin(ph) * 0.045;
        localPos.z += cos(ph * 0.85) * 0.035;
    }
    #endif

    vec4 viewPos = gl_ModelViewMatrix * localPos;
    vViewDist = length(viewPos.xyz);

    vec3 rawNorm = gl_NormalMatrix * gl_Normal;
    vec3 viewNormal = dot(rawNorm, rawNorm) > 1e-6 ? normalize(rawNorm) : vec3(0.0, 1.0, 0.0);
    vec3 lightDir = dot(shadowLightPosition, shadowLightPosition) > 1e-6 ? normalize(shadowLightPosition) : vec3(0.0, 1.0, 0.0);
    vec3 upDir = dot(upPosition, upPosition) > 1e-6 ? normalize(upPosition) : vec3(0.0, 1.0, 0.0);
    // Soft wrap NdotL keeps foliage and stone pleasingly sculpted on mobile screens
    vNdotL = clamp(dot(viewNormal, lightDir) * 0.85 + 0.15, 0.0, 1.0);
    vSkyHemi = dot(viewNormal, upDir) * 0.25 + 0.75;

    // Compute shadow clip position PER VERTEX so fragment shader pays ZERO mat4 multiplies!
    vec4 playerPos = gbufferModelViewInverse * viewPos;
    vec4 shClip = shadowProjection * (shadowModelView * playerPos);
    float dist = length(shClip.xy);
    float distort = mix(1.0, dist, 0.72);
    shClip.xy /= max(distort, 0.001);
    vShadowCoord = vec4(shClip.xyz * 0.5 + 0.5, playerPos.y);

    gl_Position = gl_ProjectionMatrix * viewPos;
}
