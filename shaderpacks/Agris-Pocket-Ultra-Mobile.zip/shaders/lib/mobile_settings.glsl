#define MOBILE_SHADOWS
#define SHADOW_TAPS 1 // [1 2]
const int shadowMapResolution = 1024; // [512 768 1024 1536 2048]
const float shadowDistance = 96.0;
const float sunPathRotation = -32.0;
const int colortex0Format = RGBA8;

#define WAVING_FOLIAGE
#define WATER_SHIMMER
#define DYNAMIC_HAND_LIGHT
#define BLOOM_TENT

#define TORCH_INTENSITY 1.25 // [0.75 1.0 1.25 1.5 2.0]
#define SUN_WARMTH 1.15 // [0.85 1.0 1.15 1.35]
#define AMBIENT_BOOST 1.05 // [0.85 1.0 1.05 1.20 1.40]
#define BLOOM_AMOUNT 0.16 // [0.08 0.12 0.16 0.24 0.32]
#define SATURATION 1.12 // [0.90 1.00 1.12 1.22 1.35]
#define EXPOSURE 1.05 // [0.85 0.95 1.05 1.15 1.30]
#define MOBILE_SHARPEN 0.30 // [0.00 0.15 0.25 0.30 0.35 0.45]
