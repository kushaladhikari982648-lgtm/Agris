#version 120
/* RENDERTARGETS: 0 */
uniform sampler2D texture;
varying vec2 vUv;
varying vec4 vColor;
void main() {
    vec4 c = texture2D(texture, vUv) * vColor;
    if (c.a < 0.02) discard;
    gl_FragData[0] = vec4(c.rgb * 1.25, 0.0);
}
