#version 120
#include "/lib/mobile_settings.glsl"
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform vec3 fogColor;
uniform float near;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
varying vec2 vUv;

vec3 acesMobile(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

void main() {
    vec2 texel = 1.0 / max(vec2(viewWidth, viewHeight), vec2(1.0));
    vec4 center = texture2D(colortex0, vUv);
    vec3 col = center.rgb;

    // Sub-pixel Contrast-Adaptive Sharpening (makes 70%–85% mobile scale look native!)
    if (MOBILE_SHARPEN > 0.001) {
        vec3 n = texture2D(colortex0, vUv + vec2(0.0, texel.y)).rgb;
        vec3 s = texture2D(colortex0, vUv - vec2(0.0, texel.y)).rgb;
        vec3 e = texture2D(colortex0, vUv + vec2(texel.x, 0.0)).rgb;
        vec3 w = texture2D(colortex0, vUv - vec2(texel.x, 0.0)).rgb;
        vec3 avg = (n + s + e + w) * 0.25;
        col = max(col + (col - avg) * MOBILE_SHARPEN, vec3(0.0));
    }

    // Single-pass 4-tap wide diagonal tent bloom (zero extra FBO pass!)
    #ifdef BLOOM_TENT
    vec2 bOff = texel * 3.5;
    vec3 b0 = texture2D(colortex0, vUv + vec2( bOff.x,  bOff.y)).rgb;
    vec3 b1 = texture2D(colortex0, vUv + vec2(-bOff.x,  bOff.y)).rgb;
    vec3 b2 = texture2D(colortex0, vUv + vec2( bOff.x, -bOff.y)).rgb;
    vec3 b3 = texture2D(colortex0, vUv + vec2(-bOff.x, -bOff.y)).rgb;
    vec3 glow = max((b0 + b1 + b2 + b3) * 0.25 - vec3(0.45), vec3(0.0));
    col += glow * BLOOM_AMOUNT;
    #endif

    // Fast rational linear depth aerial perspective (0 matrix multiplies!)
    float rawZ = texture2D(depthtex0, vUv).r;
    if (rawZ < 0.9997) {
        float zNdc = rawZ * 2.0 - 1.0;
        float linearDist = (2.0 * near * far) / max(far + near - zNdc * (far - near), 0.0001);
        float fogFactor = smoothstep(far * (0.45 - rainStrength * 0.2), far * 0.98, linearDist);
        col = mix(col, fogColor, fogFactor * 0.72);
    }

    // Exposure + ACES Filmic tonemap + OLED saturation
    col = acesMobile(col * EXPOSURE);
    float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
    col = clamp(mix(vec3(luma), col, SATURATION), 0.0, 1.0);

    gl_FragColor = vec4(col, 1.0);
}
