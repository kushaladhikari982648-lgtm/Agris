#version 120
/* RENDERTARGETS: 0 */
uniform sampler2D texture;
uniform float alphaTestRef;
varying vec2 vUv;
varying vec4 vColor;
void main() {
    vec4 c = texture2D(texture, vUv) * vColor;
    if (c.a < alphaTestRef) discard;
    gl_FragData[0] = c;
}
