#version 120
#include "/lib/mobile_settings.glsl"
/* RENDERTARGETS: 0 */
uniform sampler2D texture;
uniform sampler2D shadowtex0;
uniform float alphaTestRef;
uniform float sunAngle;
uniform float rainStrength;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

varying vec2 vUv;
varying vec2 vLightUv;
varying vec4 vColor;
varying vec4 vShadowCoord;
varying float vNdotL;
varying float vSkyHemi;
varying float vViewDist;
varying float vEmissive;

float sampleMobileShadow(vec3 sc) {
    #ifndef MOBILE_SHADOWS
    return 1.0;
    #else
    if (sc.x <= 0.002 || sc.x >= 0.998 || sc.y <= 0.002 || sc.y >= 0.998 || sc.z >= 0.999) {
        return 1.0;
    }
    float fade = 1.0 - smoothstep(shadowDistance * 0.78, shadowDistance, vViewDist);
    if (fade <= 0.001) return 1.0;
    float bias = 0.00085 + (1.0 - vNdotL) * 0.0016;
    #if SHADOW_TAPS == 1
    float vis = shadow2D(shadowtex0, vec3(sc.xy, sc.z - bias)).r;
    #else
    // 2-tap Interleaved Gradient Noise (IGN) filter: smooth penumbra in just 2 texture reads!
    float ign = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float ang = ign * 6.2831853;
    vec2 dir = vec2(cos(ang), sin(ang)) * (1.15 / float(shadowMapResolution));
    float s0 = shadow2D(shadowtex0, vec3(sc.xy + dir, sc.z - bias)).r;
    float s1 = shadow2D(shadowtex0, vec3(sc.xy - dir, sc.z - bias)).r;
    float vis = 0.5 * (s0 + s1);
    #endif
    return mix(1.0, vis, fade);
    #endif
}

void main() {
    vec4 albedo = texture2D(texture, vUv) * vColor;
    if (albedo.a < alphaTestRef) discard;

    float blockLight = clamp((vLightUv.x - 0.03125) / 0.9375, 0.0, 1.0);
    float skyLight   = clamp((vLightUv.y - 0.03125) / 0.9375, 0.0, 1.0);

    // Day / sunset / night celestial color curve
    float isNight = step(0.5, sunAngle);
    float dayPhase = sin(sunAngle * 6.2831853);
    float daylight = clamp(dayPhase * 2.2 + 0.15, 0.0, 1.0) * (1.0 - isNight);
    float twilight = exp(-abs(dayPhase) * 9.0) * (1.0 - rainStrength * 0.7);

    vec3 sunCol = mix(vec3(1.02, 0.95, 0.84), vec3(1.22, 0.64, 0.32), twilight) * SUN_WARMTH;
    vec3 moonCol = vec3(0.20, 0.28, 0.46);
    vec3 directCol = mix(moonCol, sunCol, daylight) * (1.0 - rainStrength * 0.62);

    vec3 skyAmb = mix(vec3(0.055, 0.075, 0.13), vec3(0.36, 0.46, 0.64), daylight);
    skyAmb = mix(skyAmb, vec3(0.30, 0.33, 0.38), rainStrength * 0.65);

    float sh = (vNdotL > 0.02 && skyLight > 0.04) ? sampleMobileShadow(vShadowCoord.xyz) : 0.0;
    vec3 lit = skyAmb * (skyLight * skyLight * vSkyHemi * AMBIENT_BOOST) + vec3(0.028 * AMBIENT_BOOST);
    lit += directCol * (vNdotL * sh * smoothstep(0.05, 0.55, skyLight));

    // Warm quadratic torch & lava glow + pocket held-light falloff
    float heldLevel = float(max(heldBlockLightValue, heldBlockLightValue2));
    #ifdef DYNAMIC_HAND_LIGHT
    if (heldLevel > 0.5) {
        float handAtten = clamp(1.0 - vViewDist / (heldLevel * 1.15), 0.0, 1.0);
        blockLight = max(blockLight, handAtten * (heldLevel / 15.0));
    }
    #endif
    vec3 torchCol = vec3(1.08, 0.66, 0.30) * (pow(blockLight, 2.25) * TORCH_INTENSITY);
    lit += torchCol;

    vec3 finalRgb = albedo.rgb * lit;
    if (vEmissive > 0.5) {
        finalRgb = albedo.rgb * (1.35 * TORCH_INTENSITY);
    }
    gl_FragData[0] = vec4(clamp(finalRgb, 0.0, 1.0), albedo.a);
}
