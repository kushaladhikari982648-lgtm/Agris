#version 120
uniform sampler2D texture;
uniform float alphaTestRef;
varying vec2 vUv;
varying vec4 vColor;

void main() {
    vec4 tex = texture2D(texture, vUv) * vColor;
    if (tex.a < max(alphaTestRef, 0.1)) discard;
    gl_FragData[0] = tex;
}
