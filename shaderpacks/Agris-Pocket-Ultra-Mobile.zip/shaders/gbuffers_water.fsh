#version 120
#include "/lib/mobile_settings.glsl"
/* RENDERTARGETS: 0 */
uniform sampler2D texture;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform vec3 sunPosition;
uniform float frameTimeCounter;
uniform float sunAngle;

varying vec2 vUv;
varying vec2 vLightUv;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vViewNormal;
varying float vIsWater;

void main() {
    vec4 base = texture2D(texture, vUv) * vColor;
    if (base.a < 0.02) discard;

    float skyL = clamp((vLightUv.y - 0.03125) / 0.9375, 0.0, 1.0);
    float blkL = clamp((vLightUv.x - 0.03125) / 0.9375, 0.0, 1.0);
    float daylight = clamp(sin(sunAngle * 6.2831853) * 2.0 + 0.2, 0.08, 1.0) * (1.0 - step(0.5, sunAngle) * 0.85);

    vec3 rgb = base.rgb * (vec3(0.32, 0.44, 0.62) * daylight * skyL + vec3(1.0, 0.65, 0.30) * pow(blkL, 2.2) + 0.08);
    float alpha = base.a;

    #ifdef WATER_SHIMMER
    if (vIsWater > 0.5) {
        vec3 V = normalize(-vViewPos);
        vec3 N = normalize(vViewNormal);
        float w1 = sin(vWorldPos.x * 2.1 + frameTimeCounter * 2.2) * 0.04;
        float w2 = cos(vWorldPos.z * 2.5 - frameTimeCounter * 1.8) * 0.04;
        N = normalize(N + vec3(w1, 0.0, w2));
        float fresnel = 0.04 + 0.96 * pow(1.0 - max(dot(N, V), 0.0), 4.0);
        vec3 reflCol = mix(skyColor, fogColor, 0.45) * daylight * skyL;
        vec3 H = normalize(normalize(sunPosition) + V);
        float spec = pow(max(dot(N, H), 0.0), 48.0) * daylight * skyL;
        rgb = mix(rgb * vec3(0.62, 0.86, 0.96), reflCol, clamp(fresnel * 0.72, 0.0, 0.85)) + vec3(1.0, 0.92, 0.76) * spec * 0.55;
        alpha = clamp(mix(base.a * 0.78, 0.92, fresnel), 0.35, 0.95);
    }
    #endif
    gl_FragData[0] = vec4(clamp(rgb, 0.0, 1.0), alpha);
}
