#version 120
/* RENDERTARGETS: 0 */
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform vec3 sunPosition;
uniform float rainStrength;
varying vec4 vColor;
varying vec3 vViewPos;

void main() {
    vec3 dir = normalize(vViewPos);
    vec3 sDir = normalize(sunPosition);
    float mu = max(dot(dir, sDir), 0.0);
    float horizon = clamp(1.0 - abs(dir.y), 0.0, 1.0);
    vec3 baseSky = mix(skyColor, fogColor, horizon * horizon);
    vec3 mieGlow = vec3(1.0, 0.68, 0.36) * pow(mu, 8.0) * 0.35 * (1.0 - rainStrength * 0.8);
    gl_FragData[0] = vec4(max(baseSky + mieGlow, vColor.rgb * 0.25), 0.0);
}
