#version 120
#include "/lib/mobile_settings.glsl"
attribute vec4 mc_Entity;
uniform float frameTimeCounter;
uniform vec3 cameraPosition;
varying vec2 vUv;
varying vec4 vColor;

void main() {
    vUv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vColor = gl_Color;
    vec4 pos = gl_Vertex;
    #ifdef WAVING_FOLIAGE
    if (abs(mc_Entity.x - 10020.0) < 0.5) {
        vec3 worldPos = pos.xyz + cameraPosition;
        float phase = frameTimeCounter * 2.6 + worldPos.x * 0.7 + worldPos.z * 0.7;
        pos.x += sin(phase) * 0.045;
        pos.z += cos(phase * 0.85) * 0.035;
    }
    #endif
    gl_Position = gl_ModelViewProjectionMatrix * pos;
    // Mild pancake XY distortion keeps nearby player shadows ultra-crisp at 1024px!
    float dist = length(gl_Position.xy);
    float distort = mix(1.0, dist, 0.72);
    gl_Position.xy /= max(distort, 0.001);
}
