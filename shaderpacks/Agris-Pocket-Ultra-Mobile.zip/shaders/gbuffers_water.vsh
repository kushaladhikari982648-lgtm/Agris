#version 120
#include "/lib/mobile_settings.glsl"
attribute vec4 mc_Entity;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
varying vec2 vUv;
varying vec2 vLightUv;
varying vec4 vColor;
varying vec3 vWorldPos;
varying vec3 vViewPos;
varying vec3 vViewNormal;
varying float vIsWater;

void main() {
    vUv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLightUv = clamp((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy, 0.03125, 0.96875);
    vColor = gl_Color;
    vIsWater = abs(mc_Entity.x - 10008.0) < 0.5 ? 1.0 : 0.0;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    vViewPos = vp.xyz;
    vWorldPos = (gbufferModelViewInverse * vp).xyz + cameraPosition;
    vec3 wn = gl_NormalMatrix * gl_Normal;
    vViewNormal = dot(wn, wn) > 1e-6 ? normalize(wn) : vec3(0.0, 1.0, 0.0);
    gl_Position = gl_ProjectionMatrix * vp;
}
